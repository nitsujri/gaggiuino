INDIGO — CONTROLLER IMPLEMENTATION AND FIRST-LOAD PACKAGE

Indigo is implemented for the frozen STM32 BlackPill / PCBv3 generation.
It draws natively on the existing stock touchscreen using UART commands.
There is NO display update: keep the currently installed TFT. Original
brewGraph, graphPreview and the manual slider remain on that display.

Software checks pass; physical touchscreen and machine acceptance are pending.
No controller or display has been flashed during this implementation.
The main image is PRODUCTION firmware: boiler filling and temperature fault
handling are enabled. The historical installed backup was a sensor-only bench
image. Loading Indigo restores real pump/heater behavior when mains is used.

LOADING.txt                concrete load, first boot and rollback procedure
SPECIFICATION.txt          implemented behavior, storage and transport contract
AUDIT.txt                  parity findings, changes, evidence and limitations
feature-matrix.csv         original behavior mapped to current implementation
field-matrix.csv           original fields and new schema13 fields
ACCEPTANCE.csv             software evidence versus physical checks not run
inventory.json             original HMI inventory and current source hashes
release-status.json        artifact hashes and verification status

Built files and logs: tmp/indigo-release/
Actual C++ renderer previews: tmp/indigo-native-preview/contact-sheet.png
Earlier HTML design reference: tmp/touchscreen-indigo/ (not installable)
Historical pre-implementation audit: archive/pre-implementation/

Reproduce read-only inventory: python3 tools/touchscreen-audit/audit.py
See LOADING.txt for exact build and sanitized test commands. Run PlatformIO
commands sequentially; changing environments can remove previous build outputs.
